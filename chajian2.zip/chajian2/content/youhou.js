(function () {
  'use strict'

  const TARGET_EXTENSIONS = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.doc', '.docx', '.xls', '.xlsx', '.zip', '.rar']

  let foundResources = []
  let seenUrls = new Set()
  let observer = null
  let isObserving = false

  function createUI() {
    if (document.getElementById('sniff-floater')) return

    const floater = document.createElement('div')
    floater.id = 'sniff-floater'
    floater.innerHTML = '🔍'
    document.body.appendChild(floater)

    const panel = document.createElement('div')
    panel.id = 'sniff-panel'
    panel.innerHTML = `
      <div id="sniff-header" title="按住此处拖拽窗口">
        <h3 style="margin:0; font-size:16px;">资源嗅探器</h3>
        <span id="sniff-close" style="cursor:pointer; font-size:20px;">×</span>
      </div>
      <div id="sniff-controls">
        <button id="btn-scan" class="sniff-btn btn-scan">⚡ 扫描</button>
        <button id="btn-monitor" class="sniff-btn btn-monitor">🔴 监听</button>
        <button id="btn-clear" class="sniff-btn btn-clear">🗑️ 清空</button>
        <div class="batch-ops">
          <label style="cursor:pointer; user-select:none;">
            <input type="checkbox" id="check-all"> 全选
          </label>
          <button id="btn-dl-sel" class="sniff-btn btn-dl-sel">📥 下载选中</button>
        </div>
      </div>
      <div id="sniff-content">
        <div id="empty-tip" style="text-align:center; color:#999; margin-top:50px;">
          <p>列表空空如也</p>
        </div>
      </div>
    `
    document.body.appendChild(panel)

    floater.onclick = e => {
      e.stopPropagation()
      panel.style.display = 'flex'
    }
    panel.querySelector('#sniff-close').onmousedown = e => e.stopPropagation()
    panel.querySelector('#sniff-close').onclick = () => (panel.style.display = 'none')

    panel.querySelector('#btn-scan').onclick = () => sniffStatic()
    panel.querySelector('#btn-clear').onclick = () => clearList()

    const monitorBtn = panel.querySelector('#btn-monitor')
    monitorBtn.onclick = () => toggleMonitor(monitorBtn, floater)

    const checkAllBox = panel.querySelector('#check-all')
    checkAllBox.onchange = e => {
      const isChecked = e.target.checked
      document.querySelectorAll('.item-check').forEach(cb => (cb.checked = isChecked))
      updateDownloadBtn()
    }

    panel.querySelector('#btn-dl-sel').onclick = () => downloadSelected()
    makeDraggable(panel, panel.querySelector('#sniff-header'))
  }

  function processElement(el) {
    if (!el) return
    if (el.getAttribute && el.getAttribute('filesrc')) {
      const src = el.getAttribute('filesrc')
      const name = (el.innerText || el.textContent || '').trim()
      checkAndAdd(src, 'FILE_SRC', name)
      return
    }
    if (el.tagName === 'IMG') {
      const name = (el.getAttribute('alt') || el.getAttribute('title') || '').trim()
      checkAndAdd(el.src || el.currentSrc, 'IMAGE', name)
    }
    if (el.tagName === 'A') {
      const href = el.href
      if (href) {
        let name = (el.innerText || el.getAttribute('title') || '').trim()
        if (!name || /^(下载|点击|查看|download)$/i.test(name)) {
          if (el.parentElement && el.parentElement.tagName !== 'BODY') {
            name = el.parentElement.innerText.replace(/下载|点击|查看/g, '').trim()
          }
        }
        const lowerHref = href.toLowerCase()
        if (lowerHref.endsWith('.pdf')) checkAndAdd(href, 'PDF', name)
        else if (lowerHref.endsWith('.doc') || lowerHref.endsWith('.docx')) checkAndAdd(href, 'DOC', name)
        else if (lowerHref.endsWith('.xls') || lowerHref.endsWith('.xlsx')) checkAndAdd(href, 'XLS', name)
        else if (lowerHref.endsWith('.zip') || lowerHref.endsWith('.rar')) checkAndAdd(href, 'ZIP', name)
        else if (isImageUrl(href)) checkAndAdd(href, 'IMAGE_LINK', name)
      }
    }
    if (el.style && el.style.backgroundImage) {
      const bg = el.style.backgroundImage
      if (bg && bg !== 'none') {
        const match = bg.match(/url\(['"]?(.*?)['"]?\)/)
        if (match && match[1] && isImageUrl(match[1])) checkAndAdd(match[1], 'BG_IMG', '')
      }
    }
  }

  function scanNode(node) {
    if (!node || node.nodeType !== 1) return
    processElement(node)
    const children = node.querySelectorAll('img, a, [filesrc]')
    children.forEach(child => processElement(child))
  }

  function checkAndAdd(url, type, suggestedName) {
    if (!url || String(url).startsWith('data:')) return
    let absoluteUrl
    try {
      absoluteUrl = new URL(url, location.href).href
    } catch (e) {
      return
    }
    if (seenUrls.has(absoluteUrl)) return
    seenUrls.add(absoluteUrl)

    let finalName = suggestedName
    const urlFilename = absoluteUrl.split('/').pop().split('?')[0]
    if (!finalName) finalName = urlFilename || 'unknown_file'
    finalName = finalName.replace(/[\\/:*?"<>|\r\n]/g, '').trim()
    if (finalName.length > 80) finalName = finalName.substring(0, 80)
    const ext = getExtension(absoluteUrl)
    if (ext && !finalName.toLowerCase().endsWith(ext)) {
      finalName += ext
    }
    const resource = { url: absoluteUrl, type: type, name: finalName }
    foundResources.push(resource)
    addValToUI(resource, foundResources.length - 1)
  }

  function getExtension(url) {
    const cleanUrl = url.split('?')[0]
    const dotIndex = cleanUrl.lastIndexOf('.')
    if (dotIndex !== -1 && cleanUrl.length - dotIndex <= 6) {
      return cleanUrl.substring(dotIndex).toLowerCase()
    }
    return ''
  }

  function isImageUrl(url) {
    const clean = url.split('?')[0].toLowerCase()
    return TARGET_EXTENSIONS.some(ext => clean.endsWith(ext) && !['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.zip', '.rar'].includes(ext))
  }

  function addValToUI(res, index) {
    const container = document.getElementById('sniff-content')
    const emptyTip = document.getElementById('empty-tip')
    if (emptyTip) emptyTip.style.display = 'none'
    const row = document.createElement('div')
    row.className = 'sniff-item'
    let previewHtml = ''
    if (res.type === 'FILE_SRC' || ['IMAGE', 'BG_IMG', 'IMAGE_LINK'].includes(res.type)) {
      if (isImageUrl(res.url)) {
        previewHtml = `<img src="${res.url}" class="item-preview" onerror="this.style.display='none'">`
      } else {
        const ext = getExtension(res.url).replace('.', '') || 'FILE'
        previewHtml = `<div class="item-preview" style="display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:bold;background:#eee;color:#555;">${ext.toUpperCase().substring(0,4)}</div>`
      }
    } else {
      const extLabel = res.name.split('.').pop() || res.type
      previewHtml = `<div class="item-preview" style="display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:bold;background:#eee;color:#555;">${extLabel.toUpperCase().substring(0,4)}</div>`
    }
    row.innerHTML = `
      <input type="checkbox" class="item-check" data-idx="${index}">
      ${previewHtml}
      <div class="item-info">
        <span class="item-name" title="${res.name}">${res.name}</span>
        <a href="${res.url}" target="_blank" class="item-url" title="${res.url}">${res.url}</a>
      </div>
      <button class="mini-btn btn-copy">复制</button>
    `
    row.querySelector('.btn-copy').onclick = async e => {
      try {
        await navigator.clipboard.writeText(res.url)
        e.target.innerText = 'OK'
        setTimeout(() => (e.target.innerText = '复制'), 1000)
      } catch {}
    }
    row.querySelector('.item-check').onchange = () => {
      updateDownloadBtn()
      const all = document.getElementById('check-all')
      if (all && !row.querySelector('.item-check').checked) all.checked = false
    }
    row.onclick = e => {
      if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'A' && e.target.type !== 'checkbox') {
        const cb = row.querySelector('.item-check')
        cb.checked = !cb.checked
        cb.dispatchEvent(new Event('change'))
      }
    }
    container.insertBefore(row, container.firstChild)
  }

  function downloadSelected() {
    const checkedBoxes = document.querySelectorAll('.item-check:checked')
    if (checkedBoxes.length === 0) return
    if (!confirm(`确认下载选中的 ${checkedBoxes.length} 个文件?`)) return
    const list = []
    checkedBoxes.forEach(cb => {
      const idx = cb.getAttribute('data-idx')
      const resource = foundResources[idx]
      list.push({ url: resource.url, name: resource.name })
    })
    chrome.runtime.sendMessage({ type: 'BATCH_DOWNLOAD', payload: list }, () => {})
  }

  function clearList() {
    foundResources = []
    seenUrls.clear()
    const content = document.getElementById('sniff-content')
    if (content) content.innerHTML = `<div id="empty-tip" style="text-align:center;color:#999;margin-top:50px;"><p>列表已清空</p></div>`
    const all = document.getElementById('check-all')
    if (all) all.checked = false
    updateDownloadBtn()
  }

  function updateDownloadBtn() {
    const count = document.querySelectorAll('.item-check:checked').length
    const btn = document.getElementById('btn-dl-sel')
    if (!btn) return
    if (count > 0) {
      btn.style.display = 'inline-block'
      btn.innerHTML = `📥 下载选中 (${count})`
    } else {
      btn.style.display = 'none'
    }
  }

  function makeDraggable(element, handle) {
    let pos1 = 0,
      pos2 = 0,
      pos3 = 0,
      pos4 = 0
    handle.onmousedown = e => {
      e.preventDefault()
      pos3 = e.clientX
      pos4 = e.clientY
      element.style.transform = 'none'
      document.onmouseup = () => {
        document.onmouseup = null
        document.onmousemove = null
      }
      document.onmousemove = e2 => {
        e2.preventDefault()
        pos1 = pos3 - e2.clientX
        pos2 = pos4 - e2.clientY
        pos3 = e2.clientX
        pos4 = e2.clientY
        element.style.top = element.offsetTop - pos2 + 'px'
        element.style.left = element.offsetLeft - pos1 + 'px'
      }
    }
  }

  function toggleMonitor(btn, floater) {
    isObserving = !isObserving
    if (isObserving) {
      btn.innerHTML = '⏹ 停止'
      btn.classList.add('active')
      floater.classList.add('recording')
      startObserver()
    } else {
      btn.innerHTML = '🔴 监听'
      btn.classList.remove('active')
      floater.classList.remove('recording')
      stopObserver()
    }
  }

  function startObserver() {
    if (observer) return
    observer = new MutationObserver(mutations => {
      for (let m of mutations) {
        if (m.type === 'childList') {
          m.addedNodes.forEach(n => {
            if (n.nodeType === 1) {
              scanNode(n)
            }
          })
        } else if (m.type === 'attributes') {
          if (['src', 'href', 'filesrc'].includes(m.attributeName)) {
            processElement(m.target)
          }
        }
      }
    })
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['src', 'href', 'filesrc']
    })
  }

  function stopObserver() {
    if (observer) {
      observer.disconnect()
      observer = null
    }
  }

  function sniffStatic() {
    scanNode(document.body)
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    createUI()
    try { sniffStatic() } catch {}
  } else {
    window.addEventListener('DOMContentLoaded', () => {
      createUI()
      try { sniffStatic() } catch {}
    })
  }
})()
