# 页面资源嗅探器（Edge 扩展，youhou 版）

- 作用：依据 `youhou.md` 的 Tampermonkey 脚本重写为 MV3 扩展，在页面内提供浮动入口与面板，支持 filesrc、图片/文档类型识别、批量下载、监听 DOM 变化、复制链接。
- 匹配：默认仅作用于 `https://pmplatform.chinese.cn/*`。

## 使用
- 打开 Edge → `edge://extensions/` → 开启「开发人员模式」。
- 点击「加载解压缩的扩展」，选择本项目目录。
- 进入目标网页，右下角出现“🔍”浮标，点击打开面板。
- “扫描”进行一次性全页扫描；“监听”持续监控节点新增与 `src/href/filesrc` 属性变化；支持全选与批量下载。

## 结构
- `manifest.json` 扩展配置（MV3，内容脚本 + 后台）。
- `background.js` 负责下载（包含文件名），响应 `DOWNLOAD_FILE/BATCH_DOWNLOAD`。
- `content/youhou.js` 页面内 UI 与嗅探逻辑，移植自 `youhou.md`。
- `content/youhou.css` 面板与浮标样式。

## 权限
- `downloads`：用于批量与命名下载。
- `host_permissions`：限定为目标域名，若需泛域名可改为 `<all_urls>`。

## 可选改动
- 如需泛站点生效，将 `manifest.json` 的 `matches` 与 `host_permissions` 改为 `<all_urls>`。
- 若站点使用自定义下载接口且返回的不是直链，可在 `content/youhou.js` 的 `checkAndAdd` 中扩展提取规则，或在 `background.js` 中加入预处理。
