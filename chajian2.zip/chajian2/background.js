chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return
  if (msg.type === 'DOWNLOAD_FILE') {
    const { url, name, saveAs } = msg.payload || {}
    try {
      chrome.downloads.download({ url, filename: name || undefined, saveAs: !!saveAs }, id => {
        sendResponse({ ok: true, id })
      })
    } catch (e) {
      sendResponse({ ok: false, error: String(e) })
    }
    return true
  }
  if (msg.type === 'BATCH_DOWNLOAD') {
    const list = Array.isArray(msg.payload) ? msg.payload : []
    let done = 0
    for (let i = 0; i < list.length; i++) {
      const it = list[i]
      setTimeout(() => {
        try {
          chrome.downloads.download({ url: it.url, filename: it.name || undefined, saveAs: false }, () => {})
        } catch {}
        done++
        if (done === list.length) sendResponse({ ok: true, count: done })
      }, i * 500)
    }
    return true
  }
})
